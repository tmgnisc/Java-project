package Model;

public class Mystore {
    private String name;
    private String password;
    public String getName() {
        return name;
    }
    public   void setName() {

        this.name = name;
    }
    public String getPassword() {
        return password;
    }
    public   void setPassword() {
        this.password = password;
    }
}
